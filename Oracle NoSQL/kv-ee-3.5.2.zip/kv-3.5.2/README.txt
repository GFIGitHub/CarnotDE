Oracle NoSQL Database 12cR1.3.5.2 Enterprise Edition: 2015-12-03 08:36:49 UTC

This is Oracle NoSQL Database, version 12cR1.3.5.2 Enterprise Edition.

To view the release and installation documentation, load the
distribution file doc/index.html into your web browser.
